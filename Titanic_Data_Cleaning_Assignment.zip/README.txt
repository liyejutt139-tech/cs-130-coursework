TITANIC DATA CLEANING PROJECT
1. Install:
   py -m pip install pandas numpy matplotlib
2. Run:
   py titanic_cleaning.py
3. The script downloads train.csv automatically and creates outputs/.
4. Open outputs/cleaning_summary.txt and confirm the duplicate count.
5. Open the Word report and update the Table of Contents in Word.
6. Add actual screenshots from your own program run if your instructor
   requires terminal/VS Code screenshots.
Dataset page: https://www.kaggle.com/competitions/titanic/data
CSV mirror: https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv
GitHub: create a public repository in your own account; see report section 15.
