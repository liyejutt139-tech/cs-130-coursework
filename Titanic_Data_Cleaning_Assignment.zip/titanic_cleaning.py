"""
TITANIC DATASET - COMPLETE DATA CLEANING PRACTICAL
Dataset: Kaggle Titanic training data (891 rows, 12 columns)
Run: py -m pip install pandas numpy matplotlib
     py titanic_cleaning.py

The script downloads the CSV from a public GitHub mirror if it is not
already in this folder. It saves before/after reports and screenshot images.
"""
import os
import urllib.request
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

DATA_URL = "https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv"
DATA_FILE = "train.csv"
OUT = "outputs"
os.makedirs(OUT, exist_ok=True)

# 1. DATA COLLECTION
if not os.path.exists(DATA_FILE):
    print("Downloading Titanic dataset...")
    urllib.request.urlretrieve(DATA_URL, DATA_FILE)

# 2. LOAD RAW DATA
df = pd.read_csv(DATA_FILE)
print("\\n========== ORIGINAL DATASET ==========")
print(df.head())
print("Shape:", df.shape)
print("\\nData types and non-null counts:")
df.info()

# 3. INITIAL QUALITY CHECK
missing_before = df.isnull().sum()
duplicate_count = int(df.duplicated().sum())
print("\\n========== MISSING VALUES BEFORE CLEANING ==========")
print(missing_before)
print("\\nDuplicate rows found:", duplicate_count)

missing_before.rename("Missing_Count").to_csv(
    f"{OUT}/missing_values_before.csv"
)

# Save a visual screenshot of missing values before cleaning.
plt.figure(figsize=(10, 5))
missing_before[missing_before > 0].sort_values(ascending=False).plot(
    kind="bar", title="Missing Values Before Cleaning"
)
plt.xlabel("Dataset Columns")
plt.ylabel("Number of Missing Values")
plt.tight_layout()
plt.savefig(f"{OUT}/01_missing_before.png", dpi=160)
plt.close()

# 4. DUPLICATE HANDLING
# Remove exact duplicate rows only. Do not remove records just because
# a single field (such as Name or Ticket) is repeated.
df = df.drop_duplicates().copy()

# 5. MISSING VALUE HANDLING
# Age: replace missing values with the median.
age_median = df["Age"].median()
df["Age"] = df["Age"].fillna(age_median)

# Embarked: replace missing values with the most frequent category.
embarked_mode = df["Embarked"].mode(dropna=True)[0]
df["Embarked"] = df["Embarked"].fillna(embarked_mode)

# Cabin: too many values are missing for reliable row-level imputation.
# Remove this column from the cleaned analysis dataset and explain why.
df = df.drop(columns=["Cabin"])

# Fare: ensure any missing fare values are handled, if present.
if "Fare" in df.columns and df["Fare"].isna().any():
    df["Fare"] = df["Fare"].fillna(df["Fare"].median())

# 6. DATA TYPE / FORMAT CHECK
df["Pclass"] = df["Pclass"].astype("int64")
df["Survived"] = df["Survived"].astype("int64")
df["Sex"] = df["Sex"].astype("category")
df["Embarked"] = df["Embarked"].astype("category")

# 7. POST-CLEANING VALIDATION
missing_after = df.isnull().sum()
duplicates_after = int(df.duplicated().sum())
print("\\n========== MISSING VALUES AFTER CLEANING ==========")
print(missing_after)
print("\\nDuplicate rows after cleaning:", duplicates_after)
print("\\nCleaned dataset shape:", df.shape)

missing_after.rename("Missing_Count").to_csv(
    f"{OUT}/missing_values_after.csv"
)
df.to_csv(f"{OUT}/titanic_cleaned.csv", index=False)

# 8. BEFORE/AFTER COMPARISON TABLE
comparison = pd.DataFrame({
    "Missing Before": missing_before,
    "Missing After": missing_after.reindex(missing_before.index).fillna(0).astype(int)
})
comparison.to_csv(f"{OUT}/before_after_comparison.csv")

# 9. AFTER-CLEANING GRAPH
plt.figure(figsize=(10, 4))
missing_after.plot(kind="bar", title="Missing Values After Cleaning")
plt.xlabel("Dataset Columns")
plt.ylabel("Number of Missing Values")
plt.tight_layout()
plt.savefig(f"{OUT}/02_missing_after.png", dpi=160)
plt.close()

# 10. CLEANING SUMMARY
with open(f"{OUT}/cleaning_summary.txt", "w", encoding="utf-8") as f:
    f.write("TITANIC DATA CLEANING SUMMARY\\n")
    f.write(f"Original shape: {pd.read_csv(DATA_FILE).shape}\\n")
    f.write(f"Cleaned shape: {df.shape}\\n")
    f.write(f"Exact duplicate rows found before cleaning: {duplicate_count}\\n")
    f.write(f"Exact duplicate rows after cleaning: {duplicates_after}\\n")
    f.write("\\nMissing values before:\\n")
    f.write(missing_before.to_string())
    f.write("\\n\\nMissing values after:\\n")
    f.write(missing_after.to_string())
    f.write("\\n\\nAge missing values filled with median: " + str(age_median))
    f.write("\\nEmbarked missing values filled with mode: " + str(embarked_mode))
    f.write("\\nCabin column removed due to high missingness.")

print("\\nSUCCESS: Cleaned dataset and evidence saved in the outputs folder.")
